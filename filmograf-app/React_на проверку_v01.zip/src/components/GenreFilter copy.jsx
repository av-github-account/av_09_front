import React from "react"
import {
  Checkbox,
  CheckboxGroup,
  HStack,
  Text,
  Box,
  Circle,
  Icon,
} from "@chakra-ui/react"
import { CheckIcon } from "@chakra-ui/icons"

const GENRES = [
  { label: "Боевик", value: "Боевик", color: "#ea580b" },
  { label: "Триллер", value: "Триллер", color: "#17a34a" },
  { label: "Комедия", value: "Комедия", color: "#2463eb" },
  { label: "Драма", value: "Драма", color: "#18181b" },
]

function GenreFilter({ selectedGenres = [], onChange }) {
  return (
    <CheckboxGroup
      colorScheme="orange"
      value={selectedGenres}
      onChange={onChange}
    >
      <HStack spacing={6}>
        {GENRES.map((genre) => (
          <Checkbox
            key={genre.value}
            value={genre.value}
            iconColor="white"
            icon={<CheckIcon />}
            display="flex"
            alignItems="center"
            gap={2}
            sx={{
              ".chakra-checkbox__control": {
                w: "6",
                h: "6",
                borderRadius: "full",
                borderColor: genre.color,
                borderWidth: "2px",
                bg: selectedGenres.includes(genre.value)
                  ? genre.color
                  : "transparent",
              },
              ".chakra-checkbox__icon": {
                color: "white",
                fontSize: "10px",
              },
            }}
          >
            <Text
              fontSize="16px"
              fontWeight="500"
            >
              {genre.label}
            </Text>
          </Checkbox>
        ))}
      </HStack>
    </CheckboxGroup>
  )
}

export default GenreFilter
